"use strict"
import {createStore} from 'redux';

const reducer = function(state, action) {

}

const store = createStore(reducer);

store.subscribe(function(){
	console.log('current state is: ' + store.getState());
})

store.dispatch()